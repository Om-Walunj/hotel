import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Star, Wifi, UtensilsCrossed, Dumbbell, Car, Waves } from "lucide-react";
import heroImg from "@/assets/hero-hotel.jpg";
import roomDeluxe from "@/assets/room-deluxe.jpg";
import roomSuite from "@/assets/room-suite.jpg";
import roomStandard from "@/assets/room-standard.jpg";

const rooms = [
  { name: "Standard Room", price: 120, img: roomStandard, desc: "Comfortable elegance for the discerning traveler." },
  { name: "Deluxe Room", price: 220, img: roomDeluxe, desc: "Spacious luxury with stunning city views." },
  { name: "Premium Suite", price: 450, img: roomSuite, desc: "The pinnacle of opulence and panoramic vistas." },
];

const amenities = [
  { icon: Wifi, label: "Free Wi-Fi" },
  { icon: UtensilsCrossed, label: "Fine Dining" },
  { icon: Dumbbell, label: "Fitness Center" },
  { icon: Car, label: "Valet Parking" },
  { icon: Waves, label: "Infinity Pool" },
  { icon: Star, label: "Concierge" },
];

const Index = () => {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <img src={heroImg} alt="Grand Horizon Hotel Lobby" className="absolute inset-0 w-full h-full object-cover" width={1920} height={1080} />
        <div className="absolute inset-0 bg-primary/60" />
        <div className="relative z-10 text-center px-4 animate-fade-in">
          <p className="text-gold font-body text-sm tracking-[0.3em] uppercase mb-4">Welcome to</p>
          <h1 className="font-heading text-5xl md:text-7xl text-primary-foreground mb-6 leading-tight">
            Grand <span className="text-gold">Horizon</span>
          </h1>
          <p className="text-primary-foreground/80 font-body text-lg md:text-xl max-w-xl mx-auto mb-10">
            Where timeless elegance meets modern luxury
          </p>
          <div className="flex gap-4 justify-center">
            <Link to="/booking">
              <Button variant="hero">Book Your Stay</Button>
            </Link>
            <Link to="/rooms">
              <Button variant="outline" className="border-gold/50 text-primary-foreground hover:bg-gold/20 hover:text-primary-foreground text-base px-8 py-3 h-auto uppercase tracking-wider">
                Explore Rooms
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Rooms Preview */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <p className="text-center text-gold font-body text-sm tracking-[0.3em] uppercase mb-2">Accommodations</p>
          <h2 className="font-heading text-4xl text-center text-foreground mb-16">Our Finest Rooms</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {rooms.map((room, i) => (
              <div key={room.name} className="group bg-card rounded-lg overflow-hidden border border-border hover:border-gold/40 transition-all duration-300 hover:shadow-xl" style={{ animationDelay: `${i * 150}ms` }}>
                <div className="overflow-hidden h-56">
                  <img src={room.img} alt={room.name} loading="lazy" width={800} height={600} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-6">
                  <h3 className="font-heading text-xl text-foreground mb-2">{room.name}</h3>
                  <p className="text-muted-foreground text-sm mb-4">{room.desc}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-gold font-heading text-2xl">${room.price}<span className="text-sm text-muted-foreground font-body">/night</span></span>
                    <Link to="/booking">
                      <Button variant="gold" size="sm">Book Now</Button>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Amenities */}
      <section className="py-24 bg-primary">
        <div className="container mx-auto px-4">
          <p className="text-center text-gold font-body text-sm tracking-[0.3em] uppercase mb-2">Services</p>
          <h2 className="font-heading text-4xl text-center text-primary-foreground mb-16">Hotel Amenities</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
            {amenities.map((a) => (
              <div key={a.label} className="text-center group">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full border border-gold/30 flex items-center justify-center group-hover:bg-gold/10 transition-colors">
                  <a.icon size={24} className="text-gold" />
                </div>
                <p className="text-primary-foreground/80 text-sm font-body">{a.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-background text-center">
        <div className="container mx-auto px-4">
          <h2 className="font-heading text-4xl text-foreground mb-6">Begin Your Journey</h2>
          <p className="text-muted-foreground max-w-lg mx-auto mb-10">
            Reserve your room today and experience the elegance that awaits at Grand Horizon.
          </p>
          <Link to="/booking">
            <Button variant="hero">Reserve Now</Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Index;

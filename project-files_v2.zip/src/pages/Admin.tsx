import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { BedDouble, Users, CalendarDays, DollarSign, Search, Plus, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type Room = { id: number; name: string; type: string; price: number; status: "available" | "occupied" | "maintenance" };
type BookingEntry = { id: number; guest: string; room: string; checkIn: string; checkOut: string; status: "confirmed" | "checked-in" | "checked-out" };

const initialRooms: Room[] = [
  { id: 101, name: "Room 101", type: "Standard", price: 120, status: "available" },
  { id: 102, name: "Room 102", type: "Standard", price: 120, status: "occupied" },
  { id: 201, name: "Room 201", type: "Deluxe", price: 220, status: "available" },
  { id: 202, name: "Room 202", type: "Deluxe", price: 220, status: "maintenance" },
  { id: 301, name: "Suite 301", type: "Premium Suite", price: 450, status: "occupied" },
  { id: 302, name: "Suite 302", type: "Premium Suite", price: 450, status: "available" },
];

const initialBookings: BookingEntry[] = [
  { id: 1, guest: "Alice Johnson", room: "Room 102", checkIn: "2026-03-28", checkOut: "2026-03-31", status: "checked-in" },
  { id: 2, guest: "Bob Smith", room: "Suite 301", checkIn: "2026-03-27", checkOut: "2026-04-02", status: "checked-in" },
  { id: 3, guest: "Carol Davis", room: "Room 201", checkIn: "2026-04-01", checkOut: "2026-04-05", status: "confirmed" },
];

const statusColor = {
  available: "bg-green-100 text-green-800",
  occupied: "bg-red-100 text-red-800",
  maintenance: "bg-yellow-100 text-yellow-800",
  confirmed: "bg-blue-100 text-blue-800",
  "checked-in": "bg-green-100 text-green-800",
  "checked-out": "bg-muted text-muted-foreground",
};

const Admin = () => {
  const { toast } = useToast();
  const [tab, setTab] = useState<"overview" | "rooms" | "bookings" | "guests">("overview");
  const [rooms, setRooms] = useState(initialRooms);
  const [bookings] = useState(initialBookings);
  const [search, setSearch] = useState("");

  const stats = [
    { label: "Total Rooms", value: rooms.length, icon: BedDouble, color: "text-gold" },
    { label: "Occupied", value: rooms.filter((r) => r.status === "occupied").length, icon: Users, color: "text-destructive" },
    { label: "Bookings", value: bookings.length, icon: CalendarDays, color: "text-blue-500" },
    { label: "Revenue", value: `$${bookings.reduce((sum, b) => sum + (rooms.find((r) => r.name === b.room)?.price || 0), 0).toLocaleString()}`, icon: DollarSign, color: "text-gold" },
  ];

  const tabs = [
    { key: "overview" as const, label: "Overview" },
    { key: "rooms" as const, label: "Rooms" },
    { key: "bookings" as const, label: "Bookings" },
    { key: "guests" as const, label: "Guests" },
  ];

  return (
    <div className="min-h-screen pt-16 bg-background">
      <div className="bg-primary py-10 text-center">
        <p className="text-gold font-body text-sm tracking-[0.3em] uppercase mb-2">Management</p>
        <h1 className="font-heading text-4xl text-primary-foreground">Admin Dashboard</h1>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Tabs */}
        <div className="flex gap-2 mb-8 border-b border-border pb-4 overflow-x-auto">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`px-4 py-2 text-sm font-body rounded-t-md transition-colors ${
                tab === t.key ? "bg-gold text-accent-foreground font-semibold" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Overview */}
        {tab === "overview" && (
          <div className="space-y-8 animate-fade-in">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {stats.map((s) => (
                <div key={s.label} className="bg-card border border-border rounded-lg p-6 text-center">
                  <s.icon size={24} className={`mx-auto mb-2 ${s.color}`} />
                  <p className="font-heading text-2xl text-foreground">{s.value}</p>
                  <p className="text-muted-foreground text-xs mt-1">{s.label}</p>
                </div>
              ))}
            </div>

            <div className="bg-card border border-border rounded-lg p-6">
              <h3 className="font-heading text-lg text-foreground mb-4">Recent Bookings</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-border text-muted-foreground text-left">
                    <th className="pb-3">Guest</th><th className="pb-3">Room</th><th className="pb-3">Check-in</th><th className="pb-3">Check-out</th><th className="pb-3">Status</th>
                  </tr></thead>
                  <tbody>
                    {bookings.map((b) => (
                      <tr key={b.id} className="border-b border-border/50">
                        <td className="py-3 font-medium text-foreground">{b.guest}</td>
                        <td className="py-3 text-muted-foreground">{b.room}</td>
                        <td className="py-3 text-muted-foreground">{b.checkIn}</td>
                        <td className="py-3 text-muted-foreground">{b.checkOut}</td>
                        <td className="py-3"><span className={`text-xs px-2 py-1 rounded-full ${statusColor[b.status]}`}>{b.status}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Rooms */}
        {tab === "rooms" && (
          <div className="animate-fade-in space-y-6">
            <div className="flex gap-4 items-center">
              <div className="relative flex-1 max-w-sm">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input placeholder="Search rooms..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
              </div>
              <Button variant="gold" size="sm" onClick={() => {
                const newId = Math.max(...rooms.map(r => r.id)) + 1;
                setRooms([...rooms, { id: newId, name: `Room ${newId}`, type: "Standard", price: 120, status: "available" }]);
                toast({ title: `Room ${newId} added` });
              }}>
                <Plus size={16} /> Add Room
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {rooms.filter((r) => r.name.toLowerCase().includes(search.toLowerCase())).map((room) => (
                <div key={room.id} className="bg-card border border-border rounded-lg p-5">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h4 className="font-heading text-lg text-foreground">{room.name}</h4>
                      <p className="text-muted-foreground text-xs">{room.type}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${statusColor[room.status]}`}>{room.status}</span>
                  </div>
                  <p className="text-gold font-heading text-xl mb-3">${room.price}<span className="text-xs text-muted-foreground font-body">/night</span></p>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1" onClick={() => {
                      const next: Record<string, Room["status"]> = { available: "occupied", occupied: "maintenance", maintenance: "available" };
                      setRooms(rooms.map((r) => r.id === room.id ? { ...r, status: next[r.status] } : r));
                    }}>Toggle Status</Button>
                    <Button variant="ghost" size="sm" onClick={() => {
                      setRooms(rooms.filter((r) => r.id !== room.id));
                      toast({ title: `${room.name} removed` });
                    }}><Trash2 size={14} /></Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Bookings */}
        {tab === "bookings" && (
          <div className="animate-fade-in bg-card border border-border rounded-lg p-6">
            <h3 className="font-heading text-lg text-foreground mb-4">All Bookings</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="border-b border-border text-muted-foreground text-left">
                  <th className="pb-3">ID</th><th className="pb-3">Guest</th><th className="pb-3">Room</th><th className="pb-3">Check-in</th><th className="pb-3">Check-out</th><th className="pb-3">Status</th>
                </tr></thead>
                <tbody>
                  {bookings.map((b) => (
                    <tr key={b.id} className="border-b border-border/50">
                      <td className="py-3 text-muted-foreground">#{b.id}</td>
                      <td className="py-3 font-medium text-foreground">{b.guest}</td>
                      <td className="py-3 text-muted-foreground">{b.room}</td>
                      <td className="py-3 text-muted-foreground">{b.checkIn}</td>
                      <td className="py-3 text-muted-foreground">{b.checkOut}</td>
                      <td className="py-3"><span className={`text-xs px-2 py-1 rounded-full ${statusColor[b.status]}`}>{b.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Guests */}
        {tab === "guests" && (
          <div className="animate-fade-in bg-card border border-border rounded-lg p-6">
            <h3 className="font-heading text-lg text-foreground mb-4">Guest Directory</h3>
            <div className="space-y-4">
              {[...new Set(bookings.map((b) => b.guest))].map((guest) => {
                const guestBookings = bookings.filter((b) => b.guest === guest);
                return (
                  <div key={guest} className="flex items-center justify-between border-b border-border/50 pb-4">
                    <div>
                      <p className="font-medium text-foreground">{guest}</p>
                      <p className="text-xs text-muted-foreground">{guestBookings.length} booking(s)</p>
                    </div>
                    <Badge variant="outline" className="border-gold/30 text-gold">{guestBookings[0].status}</Badge>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Admin;

import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

const Login = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast({ title: "Please enter email and password", variant: "destructive" });
      return;
    }
    // Demo login — will connect to database later
    if (email === "admin@hotel.com" && password === "admin123") {
      toast({ title: "Welcome back, Admin!" });
      navigate("/admin");
    } else {
      toast({ title: "Login successful", description: "Welcome to Grand Horizon!" });
      navigate("/");
    }
  };

  return (
    <div className="min-h-screen pt-16 flex items-center justify-center bg-background">
      <div className="w-full max-w-md p-8 bg-card border border-border rounded-lg animate-fade-in">
        <div className="text-center mb-8">
          <h1 className="font-heading text-3xl text-foreground mb-2">Welcome Back</h1>
          <p className="text-muted-foreground text-sm">Sign in to your Grand Horizon account</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-5">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
          </div>
          <Button type="submit" variant="gold" className="w-full">Sign In</Button>
        </form>

        <p className="text-center text-sm text-muted-foreground mt-6">
          Don't have an account?{" "}
          <Link to="/register" className="text-gold hover:underline font-medium">Register</Link>
        </p>
        <p className="text-center text-xs text-muted-foreground mt-4">
          Demo: admin@hotel.com / admin123
        </p>
      </div>
    </div>
  );
};

export default Login;

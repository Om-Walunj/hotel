import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarDays, Users, BedDouble, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Booking = () => {
  const { toast } = useToast();
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "", email: "", phone: "", checkIn: "", checkOut: "", roomType: "", guests: "1", specialRequests: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.checkIn || !form.checkOut || !form.roomType) {
      toast({ title: "Please fill in all required fields", variant: "destructive" });
      return;
    }
    setSubmitted(true);
    toast({ title: "Booking request submitted!", description: "We'll confirm your reservation shortly." });
  };

  if (submitted) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center bg-background">
        <div className="text-center space-y-6 animate-fade-in">
          <CheckCircle size={64} className="mx-auto text-gold" />
          <h2 className="font-heading text-3xl text-foreground">Booking Confirmed!</h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            Thank you, {form.name}. Your reservation for a {form.roomType} from {form.checkIn} to {form.checkOut} has been submitted. A confirmation email will be sent to {form.email}.
          </p>
          <Button variant="gold" onClick={() => setSubmitted(false)}>Make Another Booking</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-16">
      <div className="bg-primary py-20 text-center">
        <p className="text-gold font-body text-sm tracking-[0.3em] uppercase mb-2">Reservations</p>
        <h1 className="font-heading text-5xl text-primary-foreground">Book Your Stay</h1>
      </div>

      <div className="container mx-auto px-4 py-16 max-w-2xl">
        <form onSubmit={handleSubmit} className="space-y-6 bg-card p-8 rounded-lg border border-border">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="John Doe" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="john@example.com" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input id="phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+1 (555) 000-0000" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="checkIn" className="flex items-center gap-2"><CalendarDays size={14} className="text-gold" /> Check-in *</Label>
              <Input id="checkIn" type="date" value={form.checkIn} onChange={(e) => setForm({ ...form, checkIn: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="checkOut" className="flex items-center gap-2"><CalendarDays size={14} className="text-gold" /> Check-out *</Label>
              <Input id="checkOut" type="date" value={form.checkOut} onChange={(e) => setForm({ ...form, checkOut: e.target.value })} />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="flex items-center gap-2"><BedDouble size={14} className="text-gold" /> Room Type *</Label>
              <Select value={form.roomType} onValueChange={(v) => setForm({ ...form, roomType: v })}>
                <SelectTrigger><SelectValue placeholder="Select room" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Standard Room">Standard Room — $120/night</SelectItem>
                  <SelectItem value="Deluxe Room">Deluxe Room — $220/night</SelectItem>
                  <SelectItem value="Premium Suite">Premium Suite — $450/night</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-2"><Users size={14} className="text-gold" /> Guests</Label>
              <Select value={form.guests} onValueChange={(v) => setForm({ ...form, guests: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {[1, 2, 3, 4].map((n) => (
                    <SelectItem key={n} value={String(n)}>{n} Guest{n > 1 ? "s" : ""}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="special">Special Requests</Label>
            <textarea
              id="special"
              value={form.specialRequests}
              onChange={(e) => setForm({ ...form, specialRequests: e.target.value })}
              placeholder="Any special requirements..."
              className="w-full min-h-[100px] rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>

          <Button type="submit" variant="hero" className="w-full">Confirm Reservation</Button>
        </form>
      </div>
    </div>
  );
};

export default Booking;

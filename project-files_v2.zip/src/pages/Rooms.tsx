import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Users, Maximize, Wifi, Coffee } from "lucide-react";
import roomDeluxe from "@/assets/room-deluxe.jpg";
import roomSuite from "@/assets/room-suite.jpg";
import roomStandard from "@/assets/room-standard.jpg";

const allRooms = [
  { id: 1, name: "Standard Room", price: 120, img: roomStandard, guests: 2, size: "28 m²", desc: "A cozy retreat featuring modern amenities, a queen-size bed, and elegant décor. Perfect for solo travelers or couples.", features: ["Free Wi-Fi", "Room Service", "Mini Bar", "Air Conditioning"] },
  { id: 2, name: "Deluxe Room", price: 220, img: roomDeluxe, guests: 3, size: "42 m²", desc: "Spacious and refined with a king-size bed, city views, and premium furnishings for an elevated stay.", features: ["Free Wi-Fi", "City View", "Room Service", "Bathrobe & Slippers", "Mini Bar"] },
  { id: 3, name: "Premium Suite", price: 450, img: roomSuite, guests: 4, size: "75 m²", desc: "Our finest accommodation with a separate living area, panoramic views, and exclusive access to the executive lounge.", features: ["Free Wi-Fi", "Panoramic View", "Executive Lounge", "Butler Service", "Jacuzzi", "Living Room"] },
];

const Rooms = () => {
  return (
    <div className="min-h-screen pt-16">
      <div className="bg-primary py-20 text-center">
        <p className="text-gold font-body text-sm tracking-[0.3em] uppercase mb-2">Accommodations</p>
        <h1 className="font-heading text-5xl text-primary-foreground">Our Rooms & Suites</h1>
      </div>

      <div className="container mx-auto px-4 py-16 space-y-16">
        {allRooms.map((room, i) => (
          <div key={room.id} className={`flex flex-col ${i % 2 === 1 ? 'md:flex-row-reverse' : 'md:flex-row'} gap-8 items-center`}>
            <div className="w-full md:w-1/2 overflow-hidden rounded-lg">
              <img src={room.img} alt={room.name} loading="lazy" width={800} height={600} className="w-full h-80 object-cover hover:scale-105 transition-transform duration-500" />
            </div>
            <div className="w-full md:w-1/2 space-y-4">
              <h2 className="font-heading text-3xl text-foreground">{room.name}</h2>
              <p className="text-muted-foreground leading-relaxed">{room.desc}</p>
              <div className="flex gap-6 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Users size={16} className="text-gold" /> {room.guests} Guests</span>
                <span className="flex items-center gap-1"><Maximize size={16} className="text-gold" /> {room.size}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {room.features.map((f) => (
                  <span key={f} className="text-xs bg-secondary text-secondary-foreground px-3 py-1 rounded-full">{f}</span>
                ))}
              </div>
              <div className="flex items-center gap-6 pt-4">
                <span className="text-gold font-heading text-3xl">${room.price}<span className="text-sm text-muted-foreground font-body">/night</span></span>
                <Link to="/booking">
                  <Button variant="gold">Book This Room</Button>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Rooms;

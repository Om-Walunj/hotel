import { Link } from "react-router-dom";
import { Phone, Mail, MapPin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div className="md:col-span-1">
            <h3 className="font-heading text-2xl mb-4">
              Grand <span className="text-gold">Horizon</span>
            </h3>
            <p className="text-primary-foreground/70 text-sm leading-relaxed">
              Where luxury meets comfort. Experience world-class hospitality in the heart of the city.
            </p>
          </div>

          <div>
            <h4 className="font-heading text-lg mb-4 text-gold">Quick Links</h4>
            <div className="space-y-2">
              {[{ to: "/rooms", label: "Our Rooms" }, { to: "/booking", label: "Book Now" }, { to: "/login", label: "Guest Login" }].map((link) => (
                <Link key={link.to} to={link.to} className="block text-sm text-primary-foreground/70 hover:text-gold transition-colors">
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-heading text-lg mb-4 text-gold">Contact</h4>
            <div className="space-y-3 text-sm text-primary-foreground/70">
              <div className="flex items-center gap-2"><Phone size={14} className="text-gold" /> +1 (555) 123-4567</div>
              <div className="flex items-center gap-2"><Mail size={14} className="text-gold" /> info@grandhorizon.com</div>
              <div className="flex items-center gap-2"><MapPin size={14} className="text-gold" /> 123 Luxury Ave, NY 10001</div>
            </div>
          </div>

          <div>
            <h4 className="font-heading text-lg mb-4 text-gold">Hours</h4>
            <div className="space-y-2 text-sm text-primary-foreground/70">
              <p>Check-in: 3:00 PM</p>
              <p>Check-out: 11:00 AM</p>
              <p>Front Desk: 24/7</p>
            </div>
          </div>
        </div>

        <div className="border-t border-gold/20 mt-12 pt-8 text-center text-xs text-primary-foreground/50">
          © {new Date().getFullYear()} Grand Horizon Hotel. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;
